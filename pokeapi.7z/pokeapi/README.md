# Desafío HTML, CSS y SASS

## Objetivo

- [frontendmentor.io](https://www.frontendmentor.io/challenges/profile-card-component-cfArpWshJ)
- [https://practica-pokemon-cards.netlify.app/](https://practica-pokemon-cards.netlify.app/)
